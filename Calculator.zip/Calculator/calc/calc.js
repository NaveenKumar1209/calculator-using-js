var http = require('http');
var fs = require('fs');
http.createServer(function(request, response){
    fs.readFile('simple_calc.html',function (err, data){
        response.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        response.write(data);
        response.end();
 console.log("Request received");
    });
}).listen(3000);
console.log("Server running...");