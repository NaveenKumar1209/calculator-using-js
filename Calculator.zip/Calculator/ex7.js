var calculator=require('./calculator');
//import require from 'requirejs';
var http=require("http");
var url=require("url");
var querystring=require("querystring");
function onRequest(req,res)
{
    var path=url.parse(req.url).pathname;
    console.log('Request for'+path+'recieved');
    var query=url.parse(req.url).query;
    console.log(query);
    var a=querystring.parse(query)["a"];
    var b=querystring.parse(query)["b"];
    var operator=querystring.parse(query)["operator"];
    res.writeHead(200,{"Content-Type":"text/html"});
    res.write("<style>");
    res.write("body{background-color:darkkhaki;}h2{color:green;text-align:center;font-family: 'Times New Roman', Times, serif;padding:10px;margin:2px; }h1{font-size:25px; color:red;text-align:center;font-style: italic;font-family: 'Times New Roman', Times, serif;padding:10px;margin:2px;}p{color:blue;text-align: center;font-size:20px;font-family: 'Times New Roman', Times, serif;padding:2px;margin:8px;}");
    res.write("</style>");
    res.write("<h2>Simple calculation<h2>");
    res.write("<center><p>First Number is : "+a+"</p><br>");
    res.write("<center><p>Second Number is : "+b+"</p><br>");
    if(operator=='+'){
    res.write("<h1>The addition of "+a+" and " +b+ " is : "+calculator.add(a,b)+"</h1><br>");}
    else if(operator=='-'){
    res.write("<h1>The subtraction of " +a +" and " +b+ " is : "+calculator.sub(a,b)+"</h1><br>");}
    else if(operator=='*'){
    res.write("<h1>The multiplication of " +a+ " and " +b+ " is : "+calculator.mul(a,b)+"</h1><br>");}
    else if(operator=='/'){
    res.write("<h1>The division of " +a+ " and "+ b+ " is : "+calculator.div(a,b)+"</h1>");}
    else if(operator=='%'){
    res.write("<h1>The modulus of " +a+ " and " +b+ " is : "+calculator.mod(a,b)+"</h1>");}
    res.end();
}
var server=http.createServer(onRequest);
server.listen(3001);
console.log("server running");