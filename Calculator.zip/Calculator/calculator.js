exports.add=function(a,b){
    return (parseInt(a)+parseInt(b));
}
exports.sub=function(a,b){
    return (parseInt(a)-parseInt(b));
}
exports.mul=function(a,b){
    return (parseInt(a)*parseInt(b));  
}
exports.div=function(a,b){
    return (parseInt(a)/parseInt(b));
}
exports.mod=function(a,b){
    return (parseInt(a)%parseInt(b));   
}